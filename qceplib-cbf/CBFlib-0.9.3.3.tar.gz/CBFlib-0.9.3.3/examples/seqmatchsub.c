/*
 *  seqmatchsub.c
 *  
 *
 *  Created by Herbert J. Bernstein on 2/24/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "seqmatchsub.h"


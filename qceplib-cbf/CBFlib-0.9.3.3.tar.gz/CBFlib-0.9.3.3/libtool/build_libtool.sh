#!/bin/sh
./ltconfig ./ltmain.sh

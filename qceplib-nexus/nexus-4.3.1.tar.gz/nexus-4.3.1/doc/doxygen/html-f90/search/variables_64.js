var searchData=
[
  ['dummy',['dummy',['../structnxmodule_1_1nxlink.html#a912657563004b0dbf6df0342f923ff26',1,'nxmodule::nxlink::dummy()'],['../structnxmodule_1_1nxhandle.html#aa9fd4de65fe838cf8ebac0ecee4be74f',1,'nxmodule::nxhandle::dummy()']]]
];

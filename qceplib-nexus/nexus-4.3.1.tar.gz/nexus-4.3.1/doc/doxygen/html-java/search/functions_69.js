var searchData=
[
  ['init',['init',['../classorg_1_1nexusformat_1_1NexusFile.html#a69e724af4d07e41a38798e649d1f23d4',1,'org::nexusformat::NexusFile']]],
  ['initattrdir',['initattrdir',['../classorg_1_1nexusformat_1_1NexusFile.html#aa9cbe9f018c97820e43f4d372b5e109f',1,'org::nexusformat::NexusFile']]],
  ['initgroupdir',['initgroupdir',['../classorg_1_1nexusformat_1_1NexusFile.html#aaaaedd314438e3b062614f09ff8c23c2',1,'org::nexusformat::NexusFile']]],
  ['inquirefile',['inquirefile',['../classorg_1_1nexusformat_1_1NexusFile.html#ae506a0976236f6db8abe45c459e03343',1,'org.nexusformat.NexusFile.inquirefile()'],['../interfaceorg_1_1nexusformat_1_1NeXusFileInterface.html#a8c0f5542d4daf7757a35ce1824a2efff',1,'org.nexusformat.NeXusFileInterface.inquirefile()']]],
  ['inttobyte',['intToByte',['../classncsa_1_1hdf_1_1hdflib_1_1HDFNativeData.html#a4ecb3508ab76aeb4d1b671dae80212d7',1,'ncsa.hdf.hdflib.HDFNativeData.intToByte(int start, int len, int[] data)'],['../classncsa_1_1hdf_1_1hdflib_1_1HDFNativeData.html#a06a9c52110088c2651413724c52b49b9',1,'ncsa.hdf.hdflib.HDFNativeData.intToByte(int data)']]],
  ['isexternaldataset',['isexternaldataset',['../classorg_1_1nexusformat_1_1NexusFile.html#a651c5b3f3d5d1a91ca57b8aaaa67d9e6',1,'org.nexusformat.NexusFile.isexternaldataset()'],['../interfaceorg_1_1nexusformat_1_1NeXusFileInterface.html#a34ac5a15b22b0f0cf04ea51004b719b7',1,'org.nexusformat.NeXusFileInterface.isexternaldataset()']]],
  ['isexternalgroup',['isexternalgroup',['../classorg_1_1nexusformat_1_1NexusFile.html#a8505a7cc98a4f3bb6736a00ffd63abdd',1,'org.nexusformat.NexusFile.isexternalgroup()'],['../interfaceorg_1_1nexusformat_1_1NeXusFileInterface.html#a2348f7eae6f88158ed76f61c49d30605',1,'org.nexusformat.NeXusFileInterface.isexternalgroup()']]]
];

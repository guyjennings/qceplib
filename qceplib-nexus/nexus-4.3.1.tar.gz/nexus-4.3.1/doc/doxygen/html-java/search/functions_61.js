var searchData=
[
  ['arrayify',['arrayify',['../classncsa_1_1hdf_1_1hdflib_1_1HDFArray.html#a96d377d1459b0142d55192c92abe9025',1,'ncsa::hdf::hdflib::HDFArray']]],
  ['attrdir',['attrdir',['../classorg_1_1nexusformat_1_1NexusFile.html#a667f3abda8675053a4a9408eb53a0ab3',1,'org.nexusformat.NexusFile.attrdir()'],['../interfaceorg_1_1nexusformat_1_1NeXusFileInterface.html#a9eddcf9b1bdabc1765af6255d5c221e4',1,'org.nexusformat.NeXusFileInterface.attrdir()']]]
];

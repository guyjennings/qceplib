var searchData=
[
  ['setnumberformat',['setnumberformat',['../classorg_1_1nexusformat_1_1NexusFile.html#a77fd5663599b25f646f1ac970dea706e',1,'org.nexusformat.NexusFile.setnumberformat()'],['../interfaceorg_1_1nexusformat_1_1NeXusFileInterface.html#a7795f0f0b4223194369732ae429b6988',1,'org.nexusformat.NeXusFileInterface.setnumberformat()']]],
  ['shorttobyte',['shortToByte',['../classncsa_1_1hdf_1_1hdflib_1_1HDFNativeData.html#a0f56fed59193aef0bee9a555bb97e58f',1,'ncsa.hdf.hdflib.HDFNativeData.shortToByte(int start, int len, short[] data)'],['../classncsa_1_1hdf_1_1hdflib_1_1HDFNativeData.html#a8bb79759979016adcc9bf48e13449056',1,'ncsa.hdf.hdflib.HDFNativeData.shortToByte(short data)']]]
];

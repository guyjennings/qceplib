var searchData=
[
  ['raiseexception',['raiseException',['../hdfexceptionImp_8c.html#a016fafd9ea3379be4b6e8f4900b5dd23',1,'raiseException(JNIEnv *env, char *message):&#160;hdfexceptionImp.c'],['../hdfexceptionImp_8h.html#a016fafd9ea3379be4b6e8f4900b5dd23',1,'raiseException(JNIEnv *env, char *message):&#160;hdfexceptionImp.c']]]
];

var searchData=
[
  ['outofmemorymessage',['OutOfMemoryMessage',['../classorg_1_1nexusformat_1_1NexusException.html#a5aeeb6966a4c6c58f09d1049cbb0b0c4',1,'org.nexusformat.NexusException.OutOfMemoryMessage()'],['../classncsa_1_1hdf_1_1hdflib_1_1HDFException.html#a6131feea39886fa02eb048cb9c1be0f2',1,'ncsa.hdf.hdflib.HDFException.OutOfMemoryMessage()']]]
];

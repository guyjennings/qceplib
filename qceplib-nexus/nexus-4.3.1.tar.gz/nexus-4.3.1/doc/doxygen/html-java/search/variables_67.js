var searchData=
[
  ['gr',['GR',['../classncsa_1_1hdf_1_1hdflib_1_1HDFConstants.html#a439181481e1072403d57811f6ed42459',1,'ncsa::hdf::hdflib::HDFConstants']]],
  ['gr_5fname',['GR_NAME',['../classncsa_1_1hdf_1_1hdflib_1_1HDFConstants.html#ab12553fb82476d59f06bc826cdc044ae',1,'ncsa::hdf::hdflib::HDFConstants']]]
];

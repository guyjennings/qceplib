var searchData=
[
  ['this_20is_20an_20implementation_20of',['This is an implementation of',['../index.html',1,'']]]
];

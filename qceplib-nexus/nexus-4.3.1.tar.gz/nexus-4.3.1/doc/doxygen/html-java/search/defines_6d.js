var searchData=
[
  ['maxhandle',['MAXHANDLE',['../handle_8h.html#ade604732c304dd674b0d1fb0ce21d3da',1,'handle.h']]]
];

/*
 * $Id: napi_exports2.c 1104 2008-10-08 12:42:42Z Freddie Akeroyd $
 *
 *  __cdecl uppercase aliases for Windows
 */

#include "napi.h"

#define CALL_MODE	__cdecl

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "napi_exports.h"

#ifdef __cplusplus
}
#endif /* __cplusplus */

